﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Desafio: Múltiplos 3!");

        for (int numero = 0; numero <= 100; numero++)
        {
            if(numero % 3 == 0)
            {
                Console.WriteLine(numero);
            }
        }

        Console.WriteLine("Tecle enter para fechar ...");
        Console.ReadLine();
    }
}
