﻿using System;

class Program
{
    static void Main(string[] args)
    {

        Console.WriteLine("Executando o projeto 6 - Atribuições de variaveis");

        int idade = 30;
        int idadeAna = idade;

        Console.WriteLine(idadeAna);

        idade = 25;

        Console.WriteLine("Tecle enter para fechar...");
        Console.ReadLine();
    }
}
