﻿using System;

class Program
{
    static void Main(string[] args)
    {
        double salario = 1000.0;

        if (salario >= 1900.0 && salario <= 2800.0)
        {
            Console.WriteLine("Seu IR é de 7,5% e você pode deduzir na declaração R$ 142,00");
        }else if (salario >= 2800.1 && salario <= 3751.0)
        {
            Console.WriteLine("Seu IR é de 15% e você pode deduzir na declaração R$ 350,00");
        }else if (salario >= 3751.01 && salario <= 4664.00)
        {
            Console.WriteLine("Seu IR é de 22,5% e você pode deduzir na declaração R$ 636,00");
        }
        else
        {
            Console.WriteLine("Você está fora da regra");
        }
            Console.ReadLine();
    }
}
