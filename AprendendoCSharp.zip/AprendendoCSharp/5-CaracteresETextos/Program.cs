﻿using System;

class Program
{
    static void Main(string[] args)
    {

        Console.WriteLine("Executando o projeto 5 - Caracteres e textos");

        char letra = 'a';
        Console.WriteLine(letra);

        letra = (char)65;
        Console.WriteLine(letra);

        letra = (char)(65 + 1);
        Console.WriteLine(letra);

        letra = (char)(86 + 1);
        Console.WriteLine(letra);

        string primeiraFrase = "Quero Café";
        Console.WriteLine(primeiraFrase + 2023);

        string vazia = "";
        Console.WriteLine(vazia);

        Console.WriteLine("Tecle enter para fechar...");
        Console.ReadLine();
    }
}
