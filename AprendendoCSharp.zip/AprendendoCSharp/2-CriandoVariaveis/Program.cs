﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Projeto 2 - Criando Variáveis");
        int idade;
        idade = 32;
        Console.WriteLine("Minha idade é: " + idade + " anos");
    }
}

