﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Olá Mundo novo!");
        Console.WriteLine("Tecle enter para fechar ...");
        Console.ReadLine();
    }
}

