﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Projeto 3 - Variáveis Ponto Flutuante");

        double salario;
        salario = 3000.35;

        Console.WriteLine("Meu salario é: " + salario);

        Console.WriteLine("Tecle enter para fechar...");
        Console.ReadLine();
    }
}

